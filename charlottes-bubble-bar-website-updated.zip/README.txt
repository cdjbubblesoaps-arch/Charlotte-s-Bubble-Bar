Charlotte's Bubble Bar Co. starter website

Files included:
- index.html
- shop.html
- about.html
- faq.html
- contact.html
- styles.css
- assets/ (your added product photos)

How to use:
1. Unzip the folder.
2. Open index.html in a web browser.
3. To publish online, upload the full folder to Shopify, Wix, Squarespace, or a basic web host.
4. Replace or add photos inside the assets folder anytime.
5. Add checkout/payment links later by editing the buttons in shop.html.

Current scent lineup added:
- Citrus Kitchen
- Lavender Lux
- Mystical Dragons Blood
- Kentucky Timber Reserve
